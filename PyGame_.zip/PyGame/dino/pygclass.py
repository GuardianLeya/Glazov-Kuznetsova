import sys

import pygame
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QWidget, QPushButton, QApplication, QLabel
from PyQt5 import QtGui
from random import randint

WIDTH = 1000
HEIGHT = 500
FPS = 50
r = 0

f = open('text.txt')
max_score = int(f.read())


class Menu(QWidget):
    def __init__(self):
        super().__init__()

        self.setGeometry(183, 135, 1000, 490)
        self.setWindowTitle('SpaceWaker')

        self.label = QLabel(self)
        self.pixmap = QPixmap('menu.jpg')
        self.label.setPixmap(self.pixmap)

        self.button_play = QPushButton('play', self)
        self.button_play.resize(150, 50)
        self.button_play.move(750, 250)
        self.button_play.setStyleSheet('background: rgb(0,0,0,0);')
        self.button_play.setFont(QtGui.QFont('Revamped', 25))
        self.button_play.clicked.connect(self.play)

        self.button_rules = QPushButton('rules', self)
        self.button_rules.resize(150, 50)
        self.button_rules.move(750, 325)
        self.button_rules.setStyleSheet('background: rgb(0,0,0,0);')
        self.button_rules.setFont(QtGui.QFont('Revamped', 25))
        self.button_rules.clicked.connect(self.rules)

        self.button_quit = QPushButton('quit', self)
        self.button_quit.resize(150, 50)
        self.button_quit.move(750, 400)
        self.button_quit.setStyleSheet('background: rgb(0,0,0,0);')
        self.button_quit.setFont(QtGui.QFont('Revamped', 25))
        self.button_quit.clicked.connect(self.quit)

        self.label = QLabel(self)
        self.label.setText('''      Record
            Score
            ''')
        self.label.resize(331, 131)
        self.label.move(500, 275)
        self.label.setFont(QtGui.QFont('Revamped', 17))

        self.label = QLabel(self)
        self.label.setText(str(max_score))
        self.label.resize(331, 131)
        self.label.move(550, 320)
        self.label.setFont(QtGui.QFont('Revamped', 35))

    def play(self):
        game = Game()

    def rules(self):
        self.documentation = Rules('''
        Hi, it's your new game! 
        I'm very glad that you play in my game,
        I really try to do best for this game.
        I hope you will enjoy it, gg!
        ''')
        self.documentation.show()

    def quit(self):
        self.close()


class Rules(QWidget):
    def __init__(self, *args):
        super().__init__()
        self.initUI(args)

    def initUI(self, args):
        self.setGeometry(300, 150, 350, 120)
        self.setFixedSize(600, 150)
        self.setWindowTitle('Rules')
        self.lbl = QLabel(args[-1], self)
        self.lbl.setStyleSheet('color: rgb(0, 0, 0);')
        self.lbl.setFont(QtGui.QFont('Revamped', 15))


class Background(pygame.sprite.Sprite):
    def __init__(self, title,  number, *args):
        self.image = pygame.image.load(title)
        self.rect = self.image.get_rect()
        self._layer = -10
        pygame.sprite.Sprite.__init__(self, *args)
        self.moved = 0
        self.number = number
        self.rect.x = self.rect.width * self.number

    def update(self):
        self.rect.move_ip(-1, 0)
        self.moved += 1

        if self.moved >= self.rect.width:
            self.rect.x = self.rect.width * self.number
            self.moved = 0


class Platform:
    def __init__(self, x, y, w, h, sp):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.sp = sp

    def move(self):
        global screen
        if self.x > -200:
            self.image = pygame.image.load('platforms.png')
            self.image = pygame.transform.scale(self.image, (self.w, self.h))
            screen.blit(self.image, (self.x, self.y))
            #  pygame.draw.self.rect(screen, (self.x, self.y, self.w, self.h))
            self.x -= self.sp
        else:
            self.x = 1000


class Crystal:
    def __init__(self, x, y, w, h, sp, n):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.sp = sp
        self.n = n
        self.flag = True
        self.t = 0

    def move(self):
        global screen
        self.t += 1
        if self.t >= 150:
            self.flag = True
        if self.x > -200:
            images = [pygame.image.load('crystal_1.png'), pygame.image.load('crystal_2.png'),
                      pygame.image.load('crystal_3.png'), pygame.image.load('crystal_4.png')]
            self.image = images[self.n]
            self.image = pygame.transform.scale(self.image, (self.w, self.h))
            if self.flag:
                screen.blit(self.image, (self.x, self.y))
            #  pygame.draw.self.rect(screen, (self.x, self.y, self.w, self.h))
            self.x -= self.sp
        else:
            self.x = 1000

    def delete(self):
        self.flag = False
        self.t = 0


class Game(QWidget):
    def __init__(self):
        super().__init__()
        global WIDTH, HEIGHT, FPS, screen, max_score, f
        pygame.init()
        screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption('Title')
        self.group = pygame.sprite.LayeredUpdates()
        Background('bg.jpg', 0, self.group)
        Background('bg.jpg', 1, self.group)

        pygame.mixer.music.load('eve.mp3')
        pygame.mixer.music.set_volume(0.35)
        pygame.mixer.music.play(-1)

        self.jump_sound = pygame.mixer.Sound('jump.mp3')
        self.crystal_sound = pygame.mixer.Sound('crystal.mp3')

        self.platforms = []
        self.create_platform(self.platforms)

        self.crystals = []
        self.create_crystal(self.crystals)
        self.score = 0

        self.go = True
        self.go_s = 0
        self.players = [pygame.transform.scale(pygame.image.load('player1.png'), (80, 150)),
                        pygame.transform.scale(pygame.image.load('player2.png'), (80, 150)),
                        pygame.transform.scale(pygame.image.load('player3.png'), (80, 150))]
        self.x_player, self.y_player = 150, 247
        self.speed = 2
        self.jump, self.down = False, False

        self.clock = pygame.time.Clock()
        self.run = True

        while self.run:
            self.clock.tick(FPS)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.run = False

            keys = pygame.key.get_pressed()

            FPS += 0.1
            self.go_s += 1
            if self.go_s >= 100:
                self.go = True
            #   x_platform -= speed
            if keys[pygame.K_ESCAPE]:
                self.pause()
            if keys[pygame.K_SPACE]:
                self.jump = True
            if self.jump:
                if self.y_player >= 245 and self.down and self.y_player < 247:
                    pygame.mixer.Sound.play(self.jump_sound)
                if self.y_player > 165 and not self.down:
                    self.y_player -= self.speed
                else:
                    self.y_player += self.speed
                    self.down = True
                    if self.y_player > 255:
                        self.game_over()
            if self.y_player >= 247 and not self.check(self.platforms):
                self.jump, self.down = False, False
            if self.check(self.platforms):
                self.jump, self.down = True, True
            if self.check_cr(self.crystals):
                self.score += 1
            screen.fill('black')
            self.group.update()
            self.group.draw(screen)
            #  screen.blit(platform, (x_platform, y_platform))
            self.draw_array(self.platforms)
            self.draw_array(self.crystals)
            self.print_text('SCORE: {}'.format(self.score), 330, 75, 50)
            self.draw_player()
            pygame.display.update()
        pygame.quit()
        if self.score > max_score:
            with open("text.txt", "w") as file:
                file.write(str(self.score))

    def game_over(self):
        pygame.mixer.music.load('stayalive.mp3')
        pygame.mixer.music.set_volume(0.2)
        pygame.mixer.music.play(1)

        pause = True
        while pause:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    if self.score > max_score:
                        with open("text.txt", "w") as file:
                            file.write(str(self.score))

            self.print_text('GAME OVER. PRESS ENTER TO PLAY AGAIN', 80, 150, 35)

            keys = pygame.key.get_pressed()
            if keys[pygame.K_RETURN]:
                pause = False
                Game()

            pygame.display.update()

    def pause(self):
        pygame.mixer.music.pause()
        pygame.mixer.music.load('eve.mp3')
        pygame.mixer.music.set_volume(0.2)
        pygame.mixer.music.play(50)
        pause = True
        while pause:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    if self.score > max_score:
                        with open("text.txt", "w") as file:
                            file.write(str(self.score))
                    pygame.quit()

            self.print_text('Paused. Press enter to continue', 60, 150)

            keys = pygame.key.get_pressed()
            if keys[pygame.K_RETURN]:
                pause = False

            pygame.display.update()
        pygame.mixer.music.unpause()

    def print_text(self, message, x, y, size=40, color=(255, 255, 255), font='pp.ttf'):
        font = pygame.font.Font(font, size)
        text = font.render(message, True, color)
        screen.blit(text, (x, y))

    def create_platform(self, array):
        self.array = array
        self.array.append(Platform(-200, 382, 200, 125, 2))
        self.array.append(Platform(100, 382, 200, 125, 2))
        self.array.append(Platform(400, 382, 200, 125, 2))
        self.array.append(Platform(700, 382, 200, 125, 2))

    def create_crystal(self, array):
        self.array = array
        self.array.append(Crystal(randint(-200, 0), randint(290, 322), 50, 60, 2, randint(0, 3)))
        self.array.append(Crystal(randint(400, 600), randint(290, 322), 50, 60, 2, randint(0, 3)))
        self.array.append(Crystal(randint(700, 900), randint(290, 322), 50, 60, 2, randint(0, 3)))

    def draw_array(self, array):
        self.array = array
        for platform in self.array:
            platform.move()

    def check(self, platforms):
        for platform in platforms:
            if self.x_player + 80 <= platform.x and platform.x - self.x_player < 100 and \
                    self.y_player + 155 >= platform.y:
                return True

    def check_cr(self, crystals):
        for crystal in crystals:
            if self.go:
                if self.x_player + 70 >= crystal.x and crystal.x + 30 >= self.x_player + 60 and \
                        self.y_player + 160 >= crystal.y:
                    pygame.mixer.Sound.play(self.crystal_sound)
                    crystal.delete()
                    self.go = False
                    self.go_s = 0
                    return True

    def draw_player(self):
        global r
        if r == 12:
            r = 0

        if not self.jump:
            screen.blit(self.players[r // 4], (self.x_player, self.y_player))
        else:
            screen.blit(self.players[1], (self.x_player, self.y_player))
        r += 1

    def __del__(self):
        pass


if __name__ == '__main__':
    app = QApplication(sys.argv)
    menu = Menu()
    menu.show()
    sys.exit(app.exec_())
